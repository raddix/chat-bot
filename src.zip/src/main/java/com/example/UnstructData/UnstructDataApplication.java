package com.example.UnstructData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.example.controller","com.example.service"})
public class UnstructDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnstructDataApplication.class, args);
	}

}
