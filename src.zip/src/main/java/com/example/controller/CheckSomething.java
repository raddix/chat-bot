package com.example.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

@Controller
public class CheckSomething implements CommandLineRunner{

	//What is the policy for admission
	
	@Override
	public void run(String... args) throws Exception {
		String input = "policy for admission";
		String[] inputArr = input.split(" ");
		List<String> inputList = new ArrayList<>();
		for(String temp : inputArr) {
			if(!shouldNotBeConsidered(temp)) {
				inputList.add(temp);
			}
		}
		System.out.println("Started running");
		Document document;
		try {
			//Get Document object after parsing the html from given url.
			document = Jsoup.connect("https://raddix.github.io/chat-bot/admissionPolicy.html").get();

			String title = document.title(); //Get title
			System.out.println("  Title: " + title); //Print title.

			Elements price = document.select(":contains(policy)");
			
			
			for (int i=0; i < price.size(); i++) {
				String temp = price.get(i).text();
				boolean worked = true;
				
				for(String an : inputList) {
					if(!temp.contains(an)) {
						worked = false;
						break;
					}
				}
				
				if(worked) {
					System.out.println(temp);
				}
				
				/*String[] tempArr = temp.split(" ");
				List<String> tempList = Arrays.asList(tempArr);
				int index = tempList.indexOf("policy");
				String back = "";
				String forward = "";
				
				int x = index-1;
				while (x>=0) {
					if(!shouldNotBeConsidered(tempList.get(x))) {
						back = tempList.get(x);
						break;
					}
					x--;
				}
				
				x = index+1;
				
				while (x<tempList.size()) {
					if(!shouldNotBeConsidered(tempList.get(x))) {
						forward = tempList.get(x);
						break;
					}
					x++;
				}
				
				System.out.println(back+" "+"policy"+" "+forward);*/
				
				
				
			}
			
			

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private boolean shouldNotBeConsidered(String input) {
		Map<String,String> map= new HashMap<>();
		map.put("his", "his");
		map.put("her", "his");
		map.put("our", "his");
		map.put("ours", "his");
		map.put("of", "his");
		map.put("the", "his");
		map.put("my", "his");
		map.put("on", "his");
		map.put("with", "his");
		map.put("that", "his");
		map.put("equal", "his");
		map.put("accordance", "his");
		map.put("in", "his");
		map.put("for", "his");
		map.put("his", "his");
		map.put("his", "his");
		
		if(map.containsKey(input.toLowerCase()))
			return true;
		return false;
	}

}
