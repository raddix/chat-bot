package com.example.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.InputRequest;
import com.example.service.UnstructService;

@RestController
public class MajorController {
	
	@Autowired
	private UnstructService unstructService;

	@PostMapping("/getDetails")
	public Map<String,Object> getSearchedData(@RequestBody InputRequest inputRequest) {
		System.out.println(inputRequest.getInputKeyword());
		String newInput = inputRequest.getInputKeyword().replace("what is the ", "");
		System.out.println(newInput);
		Map<String,Object> map = new HashMap<>();
		List<String> list = unstructService.possibleValues(newInput);
		if(list.isEmpty()) {
			map.put("result", "No Value");
			return map;
		}
		if(list.size()>2) {
			map.put("result", "What kind of "+inputRequest.getInputKeyword()+" are we talking about?");
			return map;
		}
		
		map.put("result", list);
		return map;
	}
}
