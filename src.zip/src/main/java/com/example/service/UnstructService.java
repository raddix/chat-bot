package com.example.service;

import java.util.List;

public interface UnstructService {
	
	public List<String> possibleValues(String input);

}
