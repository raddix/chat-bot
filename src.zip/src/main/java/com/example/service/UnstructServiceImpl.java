package com.example.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

@Service
public class UnstructServiceImpl implements UnstructService{
	
	@Override
	public List<String> possibleValues(String input) {
		String[] currentUrl = {"https://raddix.github.io/chat-bot/admissionPolicy.html",
				"https://raddix.github.io/chat-bot/antiRagging.html",
				"https://raddix.github.io/chat-bot/collegeRefund.html",
				"https://raddix.github.io/chat-bot/idCardPolicy.html"};
		
		List<String> list = new ArrayList<>();
		
		for(String s : currentUrl) {
			boolean checkForTheInput = hitJsoupForKeyword(input,s);
			if(checkForTheInput) {
				list.add(s);
			}
		}
		return list;
	}

	private boolean hitJsoupForKeyword(String input,String url) {
		String[] inputArr = input.split(" ");
		List<String> inputList = new ArrayList<>();
		for(String temp : inputArr) {
			if(!shouldNotBeConsidered(temp)) {
				inputList.add(temp);
			}
		}
		
		String toBeUsedInput = inputList.get(0);
		System.out.println("Started running");
		Document document;
		try {
			//Get Document object after parsing the html from given url.
			document = Jsoup.connect(url).get();

			//String title = document.title(); //Get title
			//System.out.println("  Title: " + title); //Print title.

			Elements price = document.select(":contains("+toBeUsedInput+")");
			
			for (int i=0; i < price.size(); i++) {
				String temp = price.get(i).text();
				boolean worked = true;
				temp = temp.toLowerCase();
				
				for(String an : inputList) {
					if(!temp.contains(an)) {
						worked = false;
						break;
					}
				}
				
				if(worked) {
					return true;
				}
				
			}
  
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	private boolean shouldNotBeConsidered(String input) {
		Map<String,String> map= new HashMap<>();
		map.put("his", "his");
		map.put("her", "his");
		map.put("our", "his");
		map.put("ours", "his");
		map.put("of", "his");
		map.put("the", "his");
		map.put("my", "his");
		map.put("on", "his");
		map.put("with", "his");
		map.put("that", "his");
		map.put("equal", "his");
		map.put("accordance", "his");
		map.put("in", "his");
		map.put("for", "his");
		map.put("his", "his");
		map.put("his", "his");
		
		if(map.containsKey(input.toLowerCase()))
			return true;
		return false;
	}

}
