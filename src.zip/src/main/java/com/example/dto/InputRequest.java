package com.example.dto;

public class InputRequest {
	
	private String inputKeyword;

	public String getInputKeyword() {
		return inputKeyword;
	}

	public void setInputKeyword(String inputKeyword) {
		this.inputKeyword = inputKeyword;
	}

}
